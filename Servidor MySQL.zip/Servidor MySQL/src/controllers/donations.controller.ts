import {
  Count,
  CountSchema,
  Filter,
  FilterExcludingWhere,
  repository,
  Where,
} from '@loopback/repository';
import {
  post,
  param,
  get,
  getModelSchemaRef,
  patch,
  put,
  del,
  requestBody,
  response,
} from '@loopback/rest';
import {DonationsOfFoodAndToys} from '../models';
import {DonationsOfFoodAndToysRepository} from '../repositories';

export class DonationsController {
  constructor(
    @repository(DonationsOfFoodAndToysRepository)
    public donationsOfFoodAndToysRepository : DonationsOfFoodAndToysRepository,
  ) {}

  @post('/donations-of-food-and-toys')
  @response(200, {
    description: 'DonationsOfFoodAndToys model instance',
    content: {'application/json': {schema: getModelSchemaRef(DonationsOfFoodAndToys)}},
  })
  async create(
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(DonationsOfFoodAndToys, {
            title: 'NewDonationsOfFoodAndToys',
            
          }),
        },
      },
    })
    donationsOfFoodAndToys: DonationsOfFoodAndToys,
  ): Promise<DonationsOfFoodAndToys> {
    return this.donationsOfFoodAndToysRepository.create(donationsOfFoodAndToys);
  }

  @get('/donations-of-food-and-toys/count')
  @response(200, {
    description: 'DonationsOfFoodAndToys model count',
    content: {'application/json': {schema: CountSchema}},
  })
  async count(
    @param.where(DonationsOfFoodAndToys) where?: Where<DonationsOfFoodAndToys>,
  ): Promise<Count> {
    return this.donationsOfFoodAndToysRepository.count(where);
  }

  @get('/donations-of-food-and-toys')
  @response(200, {
    description: 'Array of DonationsOfFoodAndToys model instances',
    content: {
      'application/json': {
        schema: {
          type: 'array',
          items: getModelSchemaRef(DonationsOfFoodAndToys, {includeRelations: true}),
        },
      },
    },
  })
  async find(
    @param.filter(DonationsOfFoodAndToys) filter?: Filter<DonationsOfFoodAndToys>,
  ): Promise<DonationsOfFoodAndToys[]> {
    return this.donationsOfFoodAndToysRepository.find(filter);
  }

  @patch('/donations-of-food-and-toys')
  @response(200, {
    description: 'DonationsOfFoodAndToys PATCH success count',
    content: {'application/json': {schema: CountSchema}},
  })
  async updateAll(
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(DonationsOfFoodAndToys, {partial: true}),
        },
      },
    })
    donationsOfFoodAndToys: DonationsOfFoodAndToys,
    @param.where(DonationsOfFoodAndToys) where?: Where<DonationsOfFoodAndToys>,
  ): Promise<Count> {
    return this.donationsOfFoodAndToysRepository.updateAll(donationsOfFoodAndToys, where);
  }

  @get('/donations-of-food-and-toys/{id}')
  @response(200, {
    description: 'DonationsOfFoodAndToys model instance',
    content: {
      'application/json': {
        schema: getModelSchemaRef(DonationsOfFoodAndToys, {includeRelations: true}),
      },
    },
  })
  async findById(
    @param.path.number('id') id: number,
    @param.filter(DonationsOfFoodAndToys, {exclude: 'where'}) filter?: FilterExcludingWhere<DonationsOfFoodAndToys>
  ): Promise<DonationsOfFoodAndToys> {
    return this.donationsOfFoodAndToysRepository.findById(id, filter);
  }

  @patch('/donations-of-food-and-toys/{id}')
  @response(204, {
    description: 'DonationsOfFoodAndToys PATCH success',
  })
  async updateById(
    @param.path.number('id') id: number,
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(DonationsOfFoodAndToys, {partial: true}),
        },
      },
    })
    donationsOfFoodAndToys: DonationsOfFoodAndToys,
  ): Promise<void> {
    await this.donationsOfFoodAndToysRepository.updateById(id, donationsOfFoodAndToys);
  }

  @put('/donations-of-food-and-toys/{id}')
  @response(204, {
    description: 'DonationsOfFoodAndToys PUT success',
  })
  async replaceById(
    @param.path.number('id') id: number,
    @requestBody() donationsOfFoodAndToys: DonationsOfFoodAndToys,
  ): Promise<void> {
    await this.donationsOfFoodAndToysRepository.replaceById(id, donationsOfFoodAndToys);
  }

  @del('/donations-of-food-and-toys/{id}')
  @response(204, {
    description: 'DonationsOfFoodAndToys DELETE success',
  })
  async deleteById(@param.path.number('id') id: number): Promise<void> {
    await this.donationsOfFoodAndToysRepository.deleteById(id);
  }
}
