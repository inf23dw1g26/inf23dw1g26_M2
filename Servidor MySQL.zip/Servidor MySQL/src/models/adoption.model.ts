import {Entity, model, property} from '@loopback/repository';

@model()
export class Adoption extends Entity {
  @property({
    type: 'number',
    required: true,
  })
  idAdoption: number;

  @property({
    type: 'number',
    id: true,
    generated: true,
  })
  idAnimal?: number;

  @property({
    type: 'string',
  })
  name?: string;

  @property({
    type: 'string',
    required: true,
  })
  address: string;

  @property({
    type: 'number',
    required: true,
  })
  idPerson: number;

  @property({
    type: 'number',
  })
  idVolunteer?: number;

  @property({
    type: 'string',
  })
  description?: string;


  constructor(data?: Partial<Adoption>) {
    super(data);
  }
}

export interface AdoptionRelations {
  // describe navigational properties here
}

export type AdoptionWithRelations = Adoption & AdoptionRelations;
