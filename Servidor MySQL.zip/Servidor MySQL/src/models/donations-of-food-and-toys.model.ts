import {Entity, model, property} from '@loopback/repository';

@model()
export class DonationsOfFoodAndToys extends Entity {
  @property({
    type: 'number',
    id: true,
    generated: true,
  })
  idDonation?: number;

  @property({
    type: 'number',
    required: true,
  })
  idPerson: number;

  @property({
    type: 'string',
    required: true,
  })
  type: string;

  @property({
    type: 'number',
    required: true,
  })
  quantity: number;


  constructor(data?: Partial<DonationsOfFoodAndToys>) {
    super(data);
  }
}

export interface DonationsOfFoodAndToysRelations {
  // describe navigational properties here
}

export type DonationsOfFoodAndToysWithRelations = DonationsOfFoodAndToys & DonationsOfFoodAndToysRelations;
