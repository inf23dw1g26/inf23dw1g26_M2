import {Entity, model, property} from '@loopback/repository';

@model()
export class Volunteer extends Entity {
  @property({
    type: 'number',
    id: true,
    generated: true,
  })
  idVolunteer?: number;

  @property({
    type: 'string',
    required: true,
  })
  name: string;

  @property({
    type: 'date',
  })
  anoInicioVolunteering?: string;

  @property({
    type: 'string',
    required: true,
  })
  phoneNumber: string;

  @property({
    type: 'string',
    required: true,
  })
  address: string;


  constructor(data?: Partial<Volunteer>) {
    super(data);
  }
}

export interface VolunteerRelations {
  // describe navigational properties here
}

export type VolunteerWithRelations = Volunteer & VolunteerRelations;
