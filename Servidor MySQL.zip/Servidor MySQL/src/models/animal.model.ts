import {Entity, model, property} from '@loopback/repository';

@model()
export class Animal extends Entity {
  @property({
    type: 'number',
    id: true,
    generated: true,
  })
  idAnimal?: number;

  @property({
    type: 'string',
    required: true,
  })
  name: string;

  @property({
    type: 'number',
  })
  age?: number;

  @property({
    type: 'string',
    required: true,
  })
  typeAnimal: string;

  @property({
    type: 'string',
  })
  breed?: string;

  @property({
    type: 'string',
  })
  description?: string;


  constructor(data?: Partial<Animal>) {
    super(data);
  }
}

export interface AnimalRelations {
  // describe navigational properties here
}

export type AnimalWithRelations = Animal & AnimalRelations;
