import {inject} from '@loopback/core';
import {DefaultCrudRepository} from '@loopback/repository';
import {DoacaodeanimaisDataSource} from '../datasources';
import {Adoption, AdoptionRelations} from '../models';

export class AdoptionRepository extends DefaultCrudRepository<
  Adoption,
  typeof Adoption.prototype.idAnimal,
  AdoptionRelations
> {
  constructor(
    @inject('datasources.mySQl') dataSource: DoacaodeanimaisDataSource,
  ) {
    super(Adoption, dataSource);
  }
}
