import {inject} from '@loopback/core';
import {DefaultCrudRepository} from '@loopback/repository';
import {DoacaodeanimaisDataSource} from '../datasources';
import {Volunteer, VolunteerRelations} from '../models';

export class VolunteerRepository extends DefaultCrudRepository<
  Volunteer,
  typeof Volunteer.prototype.idVolunteer,
  VolunteerRelations
> {
  constructor(
    @inject('datasources.mySQl') dataSource: DoacaodeanimaisDataSource,
  ) {
    super(Volunteer, dataSource);
  }
}
