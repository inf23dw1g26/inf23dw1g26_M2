import {inject} from '@loopback/core';
import {DefaultCrudRepository} from '@loopback/repository';
import {DoacaodeanimaisDataSource} from '../datasources';
import {Animal, AnimalRelations} from '../models';

export class AnimalRepository extends DefaultCrudRepository<
  Animal,
  typeof Animal.prototype.idAnimal,
  AnimalRelations
> {
  constructor(
    @inject('datasources.mySQl') dataSource: DoacaodeanimaisDataSource,
  ) {
    super(Animal, dataSource);
  }
}
