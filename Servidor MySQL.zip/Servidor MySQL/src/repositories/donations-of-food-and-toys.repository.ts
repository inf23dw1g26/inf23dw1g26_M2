import {inject} from '@loopback/core';
import {DefaultCrudRepository} from '@loopback/repository';
import {DoacaodeanimaisDataSource} from '../datasources';
import {DonationsOfFoodAndToys, DonationsOfFoodAndToysRelations} from '../models';

export class DonationsOfFoodAndToysRepository extends DefaultCrudRepository<
  DonationsOfFoodAndToys,
  typeof DonationsOfFoodAndToys.prototype.idDonation,
  DonationsOfFoodAndToysRelations
> {
  constructor(
    @inject('datasources.mySQl') dataSource: DoacaodeanimaisDataSource,
  ) {
    super(DonationsOfFoodAndToys, dataSource);
  }
}
