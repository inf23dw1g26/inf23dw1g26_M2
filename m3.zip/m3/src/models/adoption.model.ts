import {Entity, model, property, hasMany, hasOne} from '@loopback/repository';
import {Animal} from './animal.model';
import {Volunteer} from './volunteer.model';

@model()
export class Adoption extends Entity {
  @property({
    type: 'number',
    id: true,
    generated: true,
  })
  idAdoption?: number;

  @property({
    type: 'number',
    required: true,
  })
  idAnimal: number;

  @property({
    type: 'string',
  })
  name?: string;

  @property({
    type: 'string',
  })
  address?: string;

  @property({
    type: 'number',
    required: true,
  })
  idPerson: number;

  @property({
    type: 'number',
  })
  idVolunteer?: number;

  @property({
    type: 'string',
  })
  description?: string;

  @hasMany(() => Animal)
  animals: Animal[];

  @property({
    type: 'number',
  })
  volunteerId?: number;

  @hasOne(() => Volunteer)
  volunteer: Volunteer;

  constructor(data?: Partial<Adoption>) {
    super(data);
  }
}

export interface AdoptionRelations {
  // describe navigational properties here
}

export type AdoptionWithRelations = Adoption & AdoptionRelations;
