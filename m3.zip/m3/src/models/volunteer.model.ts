import {Entity, model, property, hasMany} from '@loopback/repository';
import {Adoption} from './adoption.model';

@model()
export class Volunteer extends Entity {
  @property({
    type: 'number',
    id: true,
    generated: true,
  })
  idVolunteer?: number;

  @property({
    type: 'string',
    required: true,
  })
  name: string;

  @property({
    type: 'number',
  })
  anoInicioVolunteering?: number;

  @property({
    type: 'number',
    required: true,
  })
  phoneNumber: number;

  @property({
    type: 'string',
  })
  address?: string;

  @hasMany(() => Adoption)
  adoptions: Adoption[];

  @property({
    type: 'number',
  })
  adoptionId?: number;

  constructor(data?: Partial<Volunteer>) {
    super(data);
  }
}

export interface VolunteerRelations {
  // describe navigational properties here
}

export type VolunteerWithRelations = Volunteer & VolunteerRelations;
