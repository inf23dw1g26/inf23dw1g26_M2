import {
  Count,
  CountSchema,
  Filter,
  repository,
  Where,
} from '@loopback/repository';
import {
  del,
  get,
  getModelSchemaRef,
  getWhereSchemaFor,
  param,
  patch,
  post,
  requestBody,
} from '@loopback/rest';
import {
  Adoption,
  Volunteer,
} from '../models';
import {AdoptionRepository} from '../repositories';

export class AdoptionVolunteerController {
  constructor(
    @repository(AdoptionRepository) protected adoptionRepository: AdoptionRepository,
  ) { }

  @get('/adoptions/{id}/volunteer', {
    responses: {
      '200': {
        description: 'Adoption has one Volunteer',
        content: {
          'application/json': {
            schema: getModelSchemaRef(Volunteer),
          },
        },
      },
    },
  })
  async get(
    @param.path.number('id') id: number,
    @param.query.object('filter') filter?: Filter<Volunteer>,
  ): Promise<Volunteer> {
    return this.adoptionRepository.volunteer(id).get(filter);
  }

  @post('/adoptions/{id}/volunteer', {
    responses: {
      '200': {
        description: 'Adoption model instance',
        content: {'application/json': {schema: getModelSchemaRef(Volunteer)}},
      },
    },
  })
  async create(
    @param.path.number('id') id: typeof Adoption.prototype.idAdoption,
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(Volunteer, {
            title: 'NewVolunteerInAdoption',
            exclude: ['idVolunteer'],
            optional: ['adoptionId']
          }),
        },
      },
    }) volunteer: Omit<Volunteer, 'idVolunteer'>,
  ): Promise<Volunteer> {
    return this.adoptionRepository.volunteer(id).create(volunteer);
  }

  @patch('/adoptions/{id}/volunteer', {
    responses: {
      '200': {
        description: 'Adoption.Volunteer PATCH success count',
        content: {'application/json': {schema: CountSchema}},
      },
    },
  })
  async patch(
    @param.path.number('id') id: number,
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(Volunteer, {partial: true}),
        },
      },
    })
    volunteer: Partial<Volunteer>,
    @param.query.object('where', getWhereSchemaFor(Volunteer)) where?: Where<Volunteer>,
  ): Promise<Count> {
    return this.adoptionRepository.volunteer(id).patch(volunteer, where);
  }

  @del('/adoptions/{id}/volunteer', {
    responses: {
      '200': {
        description: 'Adoption.Volunteer DELETE success count',
        content: {'application/json': {schema: CountSchema}},
      },
    },
  })
  async delete(
    @param.path.number('id') id: number,
    @param.query.object('where', getWhereSchemaFor(Volunteer)) where?: Where<Volunteer>,
  ): Promise<Count> {
    return this.adoptionRepository.volunteer(id).delete(where);
  }
}
