import {inject} from '@loopback/core';
import {DefaultCrudRepository} from '@loopback/repository';
import {DbDataSource} from '../datasources';
import {Animal, AnimalRelations} from '../models';

export class AnimalRepository extends DefaultCrudRepository<
  Animal,
  typeof Animal.prototype.idAnimal,
  AnimalRelations
> {
  constructor(
    @inject('datasources.db') dataSource: DbDataSource,
  ) {
    super(Animal, dataSource);
  }
}
