import {inject, Getter} from '@loopback/core';
import {DefaultCrudRepository, repository, HasManyRepositoryFactory} from '@loopback/repository';
import {DbDataSource} from '../datasources';
import {Volunteer, VolunteerRelations, Adoption} from '../models';
import {AdoptionRepository} from './adoption.repository';

export class VolunteerRepository extends DefaultCrudRepository<
  Volunteer,
  typeof Volunteer.prototype.idVolunteer,
  VolunteerRelations
> {

  public readonly adoptions: HasManyRepositoryFactory<Adoption, typeof Volunteer.prototype.idVolunteer>;

  constructor(
    @inject('datasources.db') dataSource: DbDataSource, @repository.getter('AdoptionRepository') protected adoptionRepositoryGetter: Getter<AdoptionRepository>,
  ) {
    super(Volunteer, dataSource);
    this.adoptions = this.createHasManyRepositoryFactoryFor('adoptions', adoptionRepositoryGetter,);
    this.registerInclusionResolver('adoptions', this.adoptions.inclusionResolver);
  }
}
